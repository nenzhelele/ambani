const Http = new XMLHttpRequest();
const url = 'https://randomuser.me/api';
Http.open("GET", url);
Http.send();
var obj = new Object();
Http.onreadystatechange = (e) => {
	console.log(typeof Http.responseText);
	obj = JSON.parse(Http.responseText);
	console.log(obj.results);
	document.getElementById('picImg').src = obj.results[0].picture.large;
	//document.getElementById('firstname').innerHTML= 'Hi, My name is <br> ' + obj.results[0].name.first + ' ' + obj.results[0].name.last;
	//document.getElementById('emails').innerHTML= 'My email address is <br>' +obj.results[1].email;
	//document.getElementById('dob').innerHTML='My birthday is <br>' + obj.results[2].date ;
	//document.getElementById('location').innerHTML= 'My address is <br>' + obj.results[3].location;
	//document.getElementById('phone').innerHTML= 'My phone number is <br>' +obj.results[4].phone;
	//document.getElementById('registered').innerHTML= 'My password is<br>' + obj.results[5].registered;
}

function getFormattedDate(date) {
	let year = date.getFullYear();
	let month = (1 + date.getMonth()).toString().padStart(2, '0');
	let day = date.getDate().toString().padStart(2, '0');
	return month + '/' + day + '/' + year;
}

function bindDataOnMouseHover(x) {
	console.log(x);
	console.log(obj.results[0]);
	if (x.id == 'firstname') {
		document.getElementById('headerA').innerHTML = 'Hi, My name is <br>';
		document.getElementById('headerB').innerHTML = obj.results[0].name.first + ' ' + obj.results[0].name.last;
	}
	if (x.id == 'email') {
		document.getElementById('headerA').innerHTML = 'My email address is <br>';
		document.getElementById('headerB').innerHTML = obj.results[0].email;
	}
	if (x.id == 'dob') {
		var xx = new Date(obj.results[0].dob.date);
		console.log(xx);
		var day = xx.getDate();
		var monthIndex = xx.getMonth();
		var year = xx.getFullYear();
		document.getElementById('headerA').innerHTML = 'My birthday is <br>';
		document.getElementById('headerB').innerHTML = day + '/' + monthIndex + '/' + year;
	}
	if (x.id == 'location') {
		console.log('test');
		console.log(obj.results[0].location.postcode);
		document.getElementById('headerA').innerHTML = 'My address is <br>';
		document.getElementById('headerB').innerHTML = obj.results[0].location.street.number + ' ' + obj.results[0].location.street.name + ' ' + obj.results[0].location.postcode;
	}
	if (x.id == 'phone') {
		document.getElementById('headerA').innerHTML = 'My phone number is <br>';
		document.getElementById('headerB').innerHTML = obj.results[0].phone;
	}
	if (x.id == 'registered') {
		document.getElementById('headerA').innerHTML = 'My password is<br>';
		document.getElementById('headerB').innerHTML = obj.results[0].login.password;
	}
}